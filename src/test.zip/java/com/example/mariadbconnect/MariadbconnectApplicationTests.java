package com.example.mariadbconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MariadbconnectApplicationTests {

    @Test
    void contextLoads() {
    }

}
